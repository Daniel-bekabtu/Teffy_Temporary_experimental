from flask import Flask, render_template, redirect, request, session, url_for, jsonify, make_response
import firebase_admin
from firebase_admin import credentials, auth, db
app = Flask(__name__)
app.secret_key = '1111'  
cred = credentials.Certificate("cred.json")  
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://tchat-af17d-default-rtdb.firebaseio.com'
})
def is_logged_in():
    print(session)
    return 'uid' in session
@app.route('/')
def home():
    return render_template('Front_page_1.html')
@app.route('/login', methods=["POST","GET"])
def login():
    if(request.method == "POST"):
        user_id = request.cookies.get('uid')
        ref = db.reference(f'users/{user_id}')
        user_data = ref.get()
        if user_data:
            print(user_data)
            return jsonify({'user_data': user_data})
        else:
            return jsonify({'message': 'User not found'}), 404
    return render_template('login_page_Session_checked_1.html')
@app.route('/signup', methods=['POST','GET'])
def signup():
    if request.method == 'POST':
        data = request.get_json()
        uid = data.get('uid')
        if not uid:
            return jsonify({'message':'UID missing'}),400
        print("UID::"+uid)
        response = make_response(jsonify(url_for("login")))
        response.set_cookie('uid', uid)
        return response     
    return render_template('Get_started_Sign_up_2.html')
@app.route('/role-selection')
def role_selection():
    if not is_logged_in():
        return redirect(url_for('login'))
@app.route('/User_fetch_request', methods=["POST","GET"])
def User_fetch_uid():
    if(request.method == "POST"):
        user_id = request.cookies.get('uid')
        if user_id:
            print(user_id)
            return jsonify({user_id})
        else:
            return jsonify({'message': 'User not found'}), 404
    return render_template('login_page_Session_checked_1.html')    
@app.route('/farmer-dashboard')
def farmer_dashboard():
    return render_template('Famer_Dashboard.html')
@app.route('/invester-dashboard')
def invester_dashboard():
    if not is_logged_in():
        return redirect(url_for('login'))
    return render_template('Invester_Dashboard.html')
@app.route('/learn-more')
def learn_more():
    return render_template('Learn_more_2.html')
@app.route('/register-farm')
def register_farm():
    if not is_logged_in():
        return redirect(url_for('login'))
    return render_template('register_farm_land.html')
@app.route('/signin-selection')
def signin_selection():
    return render_template('Sign_in_login_fd_selecion.html') 
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))
if __name__ == '__main__':
    app.run(debug=True)